import { Routes } from '@angular/router';

export const routes: Routes = [

  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'home',
    loadComponent: () => import('./pages/home/home.page').then( m => m.HomePage)
  },

  /*
   source: https://stackoverflow.com/questions/36207023/angular2-how-to-use-router-with-dynamic-urls
  */
  {
    path: 'movie-details/:id',
    loadComponent: () => import('./pages/movie-details/movie-details.page').then( m => m.MovieDetailsPage)
  },
  {
    path: 'favourites',
    loadComponent: () => import('./pages/favourites/favourites.page').then( m => m.FavouritesPage)
  },
  {
    path: 'person-details/:id',
    loadComponent: () => import('./pages/person-details/person-details.page').then( m => m.PersonDetailsPage)
  },
];
